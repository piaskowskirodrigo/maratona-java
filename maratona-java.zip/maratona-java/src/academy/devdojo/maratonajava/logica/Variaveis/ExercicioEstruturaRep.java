package academy.devdojo.maratonajava.logica.Variaveis;

public class ExercicioEstruturaRep {
    public static void main(String[] args) {
        int numA = 100;
        int numB = 15;

        if (numA > numB ){
            System.out.println("O numero maior e..." + numA);
        }
        else {
            System.out.println("O numero maior e ..." + numB);
        }

    }
}
