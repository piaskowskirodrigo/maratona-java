package academy.devdojo.maratonajava.logica.Variaveis;

public class ExercicioPorcentagem {

    public static void main(String[] args) {

        double salario = 1200;
        double porcentagem = 0.15;
        double calculo = salario * porcentagem;
        double somaDeSalarioMaisPorcentagem = salario + calculo;
        System.out.println( "O  valor do salario e de : " + salario);
        System.out.println( "O  valor do salario mais a porcentagem e de : " + somaDeSalarioMaisPorcentagem);


    }
}
