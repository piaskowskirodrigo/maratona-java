package academy.devdojo.maratonajava.logica.Variaveis;

public class ExercicioImparPar {
    public static void main(String[] args) {
        int num = 1001;
        if ( (num % 2) == 0 ) {
            System.out.println("Par");
        } else {
            System.out.println("IMPAR");
        }

    }
}
