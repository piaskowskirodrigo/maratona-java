package academy.devdojo.maratonajava.logica.LacosDeRepticao.Fors;

public class ExercicioFors2 {
    public static void main(String[] args) {
        for (int i = 15; i <= 200 ; i++) {
            System.out.println(i*i);
        }
    }
}
