package academy.devdojo.maratonajava.logica.LacosDeRepticao.Fors;

public class ExercicioFors {
    public static void main(String[] args) {
        for (int i = 0;i <=10;i++){
            System.out.println(i);

        }
    }
}
