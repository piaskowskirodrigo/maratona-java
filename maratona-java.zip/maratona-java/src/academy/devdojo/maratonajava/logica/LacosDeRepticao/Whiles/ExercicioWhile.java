package academy.devdojo.maratonajava.logica.LacosDeRepticao.Whiles;

public class ExercicioWhile {
    public static void main(String[] args) {
        int contador = 0;
        while(contador < 10) {
            contador = contador + 1;
            System.out.println("Contador" + contador);
        }
    }
}
