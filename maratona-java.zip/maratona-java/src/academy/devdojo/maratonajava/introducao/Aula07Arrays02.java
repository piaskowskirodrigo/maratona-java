package academy.devdojo.maratonajava.introducao;

public class Aula07Arrays02 {
    public static void main(String[] args) {
        //byte, short, int, long, float e double 0
        //char '\u0000'''
        //boolean false
        //String null

        int[] idades = new int[3];
        System.out.println(idades[0]);

    }
}
